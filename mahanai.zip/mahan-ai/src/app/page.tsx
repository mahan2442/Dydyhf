"use client";

import { useEffect, useMemo, useRef, useState } from "react";
import ReactMarkdown from "react-markdown";
import Link from "next/link";
import { SignedIn, SignedOut, SignInButton, useClerk, useUser } from "@clerk/nextjs";
import remarkGfm from "remark-gfm";
import { Bot, ChevronDown, CircleHelp, Command, Copy, FileText, ImagePlus, Menu, MessageSquare, Moon, Plus, Send, Settings2, ShieldCheck, Sparkles, Sun, Trash2, X } from "lucide-react";

type Model = { id: string; label: string; provider: string; providerLabel: string; capabilities: string[]; description: string; configured: boolean };
type Message = { role: "user" | "assistant"; content: string; demo?: boolean };
type Thread = { id: string; title: string; updatedAt: number; messages: Message[] };

const starterPrompts = [
  { icon: "✦", title: "ایده‌پردازی کن", detail: "برای کسب‌وکارم چند ایده خلاقانه پیشنهاد بده", prompt: "برای یک کسب‌وکار آنلاین فارسی‌زبان، ۵ ایده خلاقانه و قابل اجرا پیشنهاد بده." },
  { icon: "⌘", title: "کد بنویس", detail: "یک مسئله را با کد حل کن", prompt: "یک تابع TypeScript تمیز با مدیریت خطا بنویس که یک آرایه را بر اساس کلید دلخواه گروه‌بندی کند." },
  { icon: "◈", title: "یاد بگیر", detail: "مفهوم پیچیده را ساده کن", prompt: "یادگیری ماشین را با مثال‌های ساده و مرحله‌به‌مرحله توضیح بده." },
  { icon: "↗", title: "متن را بهتر کن", detail: "یک متن حرفه‌ای آماده کن", prompt: "یک برنامه عملی ۷ روزه برای افزایش تمرکز و مدیریت بهتر زمان پیشنهاد بده." }
];


function AccountMenu({ compact = false }: { compact?: boolean }) {
  const { user } = useUser();
  const { openUserProfile, signOut } = useClerk();
  const [open, setOpen] = useState(false);
  const email = user?.primaryEmailAddress?.emailAddress ?? user?.emailAddresses?.[0]?.emailAddress ?? "";
  const initial = (email.trim()[0] || user?.firstName?.trim()[0] || "M").toLocaleUpperCase();
  return (
    <div className={`relative ${compact ? "w-full" : ""}`}>
      <button type="button" onClick={() => setOpen(v => !v)} aria-label="منوی حساب کاربری" aria-expanded={open} className={`flex items-center gap-2 rounded-full transition hover:bg-black/[.06] dark:hover:bg-white/[.08] ${compact ? "w-full rounded-xl p-2.5 text-right" : "p-1"}`}>
        <span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full bg-neutral-800 text-sm font-semibold text-white ring-1 ring-black/10 dark:bg-neutral-200 dark:text-neutral-900">{initial}</span>
        {compact && <span className="min-w-0 flex-1"><span className="block truncate text-sm font-semibold">{user?.fullName || email || "حساب کاربری"}</span><span className="muted block text-xs">مدیریت حساب و خروج</span></span>}
        {!compact && <ChevronDown size={14} className="muted" />}
      </button>
      {open && <><button className="fixed inset-0 z-40 cursor-default" aria-label="بستن منوی حساب" onClick={() => setOpen(false)} /><div dir="rtl" className={`surface absolute z-50 w-72 overflow-hidden rounded-2xl border p-2 shadow-2xl ${compact ? "bottom-full right-0 mb-2" : "left-0 top-full mt-2"}`} style={{ borderColor: "var(--line)" }}>
        <div className="flex items-center gap-3 border-b px-3 py-3" style={{ borderColor: "var(--line)" }}>
          <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-neutral-800 font-semibold text-white dark:bg-neutral-200 dark:text-neutral-900">{initial}</span>
          <span className="min-w-0"><span className="block truncate text-sm font-semibold">{user?.fullName || "حساب کاربری"}</span><span className="muted block truncate text-xs">{email}</span></span>
        </div>
        <button onClick={() => { setOpen(false); openUserProfile(); }} className="mt-2 flex w-full items-center rounded-xl px-3 py-2.5 text-sm hover:bg-black/[.05] dark:hover:bg-white/[.06]">مدیریت پروفایل</button>
        <button onClick={() => signOut({ redirectUrl: "/" })} className="flex w-full items-center rounded-xl px-3 py-2.5 text-sm text-red-600 hover:bg-red-500/10">خروج از حساب</button>
      </div></>}
    </div>
  );
}

export default function Home() {
  const [models, setModels] = useState<Model[]>([]);
  const [demoMode, setDemoMode] = useState(true);
  const [modelId, setModelId] = useState("gpt-6-luna");
  const [threads, setThreads] = useState<Thread[]>([]);
  const [activeId, setActiveId] = useState<string | null>(null);
  const { user, isLoaded: clerkLoaded } = useUser();
  const storageKey = `mahan-ai-threads-v1:${user?.id ?? "guest"}`;
  const [loadedStorageKey, setLoadedStorageKey] = useState<string | null>(null);
  const [input, setInput] = useState("");
  const [busy, setBusy] = useState(false);
  const [sidebarOpen, setSidebarOpen] = useState(true);
  const [modelMenuOpen, setModelMenuOpen] = useState(false);
  const [dark, setDark] = useState(false);
  const [language, setLanguage] = useState<"fa" | "en">("fa");
  const [usedToday, setUsedToday] = useState(0);
  const dailyLimit = 30;
  const [toast, setToast] = useState("");
  const [showSettings, setShowSettings] = useState(false);
  const textareaRef = useRef<HTMLTextAreaElement>(null);
  const bottomRef = useRef<HTMLDivElement>(null);
  const activeThread = threads.find(t => t.id === activeId);
  const selectedModel = models.find(m => m.id === modelId) ?? models[0];



  // Load each account's own conversations from this browser before enabling saves.
  useEffect(() => {
    if (!clerkLoaded) return;
    setLoadedStorageKey(null);
    try {
      const raw = localStorage.getItem(storageKey);
      const saved = raw ? JSON.parse(raw) : [];
      const valid = Array.isArray(saved) ? saved.filter((t: any) => t && typeof t.id === "string" && typeof t.title === "string" && Array.isArray(t.messages)) : [];
      setThreads(valid);
      setActiveId(null);
    } catch {
      setThreads([]);
      setActiveId(null);
    }
    setLoadedStorageKey(storageKey);
  }, [clerkLoaded, storageKey]);

  // Save changes after loading has finished, so an initial empty state never erases saved chats.
  useEffect(() => {
    if (!clerkLoaded || loadedStorageKey !== storageKey) return;
    try { localStorage.setItem(storageKey, JSON.stringify(threads)); } catch { /* Storage can be unavailable in private/restricted browsing. */ }
  }, [threads, storageKey, loadedStorageKey, clerkLoaded]);

  useEffect(() => {
    const syncSidebar = () => setSidebarOpen(window.innerWidth > 768);
    syncSidebar();
    window.addEventListener("resize", syncSidebar);
    return () => window.removeEventListener("resize", syncSidebar);
  }, []);
  useEffect(() => {
    fetch("/api/models").then(r => r.json()).then(async data => {
      setModels(data.models ?? []);
      setDemoMode(Boolean(data.demoMode));
      if (data.models?.length && !data.models.some((m: Model) => m.id === modelId)) setModelId(data.models[0].id);
    }).catch(() => setToast("بارگذاری فهرست مدل‌ها ناموفق بود."));
  }, []);
  useEffect(() => { bottomRef.current?.scrollIntoView({ behavior: "smooth" }); }, [activeThread?.messages.length, busy]);
  useEffect(() => { document.documentElement.classList.toggle("dark", dark); }, [dark]);
  useEffect(() => {
    const today = new Date().toISOString().slice(0, 10);
    try { const saved = JSON.parse(localStorage.getItem("mahan-ai-usage-v1") || "null"); setUsedToday(saved?.date === today ? Math.min(dailyLimit, Number(saved.count) || 0) : 0); } catch { setUsedToday(0); }
  }, []);
  useEffect(() => { document.documentElement.lang = language; document.documentElement.dir = language === "fa" ? "rtl" : "ltr"; }, [language]);
  useEffect(() => { if (toast) { const t = setTimeout(() => setToast(""), 3500); return () => clearTimeout(t); } }, [toast]);

  const newChat = () => {
    setActiveId(null);
    setInput("");
    textareaRef.current?.focus();
  };

  const updateThread = (id: string, messages: Message[]) => setThreads(prev => prev.map(t => t.id === id ? { ...t, messages, updatedAt: Date.now() } : t));

  async function sendMessage(text = input) {
    const content = text.trim();
    if (!content || busy) return;
    if (!selectedModel) { setToast("در حال حاضر مدلی در دسترس نیست."); return; }
    let thread = activeThread;
    setInput("");
    setBusy(true);
    try {
      if (!thread) {
        thread = { id: crypto.randomUUID(), title: content.slice(0, 36), updatedAt: Date.now(), messages: [] };
      }
      if (!threads.some(t => t.id === thread!.id)) setThreads(prev => [thread!, ...prev]);
      setActiveId(thread.id);
      const nextMessages: Message[] = [...thread.messages, { role: "user", content }];
      setThreads(prev => prev.map(t => t.id === thread!.id ? { ...t, messages: nextMessages, updatedAt: Date.now() } : t));
      const response = await fetch("/api/chat", {
        method: "POST", headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ modelId: selectedModel.id, messages: nextMessages.map(m => ({ role: m.role, content: m.content })) })
      });
      const data = await response.json().catch(() => ({}));
      if (!response.ok) throw new Error(data.error || `خطای سرور (${response.status}). لاگ‌های Render را بررسی کنید.`);
      const usageToday = Math.min(dailyLimit, usedToday + 1);
      const usageDate = new Date().toISOString().slice(0, 10);
      setUsedToday(usageToday);
      try { localStorage.setItem("mahan-ai-usage-v1", JSON.stringify({ date: usageDate, count: usageToday })); } catch {}
      setThreads(prev => prev.map(t => t.id === thread!.id ? { ...t, messages: [...t.messages, { role: "assistant", content: data.text, demo: data.demo }], updatedAt: Date.now() } : t));
    } catch (e) {
      const message = e instanceof TypeError && /fetch/i.test(e.message)
        ? "ارتباط با سرور برقرار نشد. آدرس سایت، وضعیت Deploy و لاگ‌های Render را بررسی کنید."
        : e instanceof Error ? e.message : "خطای ناشناخته";
      if (thread) setThreads(prev => prev.map(t => t.id === thread!.id ? { ...t, messages: [...t.messages, { role: "assistant", content: `**خطا در دریافت پاسخ**\n\n${message}` }], updatedAt: Date.now() } : t));
      else setToast(message);
    } finally { setBusy(false); }
  }

  async function removeThread(id: string) {
    setThreads(prev => prev.filter(t => t.id !== id));
    if (activeId === id) setActiveId(null);
  }
  async function copyText(text: string) {
    try { await navigator.clipboard.writeText(text); setToast("متن کپی شد."); }
    catch { setToast("کپی متن امکان‌پذیر نبود."); }
  }

  return <main className="app-shell flex min-h-screen overflow-hidden">
    {sidebarOpen && <button aria-label="بستن منو" className="mobile-backdrop" onClick={() => setSidebarOpen(false)} />}
    {sidebarOpen && <aside className="mobile-sidebar surface flex w-[280px] shrink-0 flex-col border-l max-md:fixed max-md:inset-y-0 max-md:right-0 max-md:z-30 max-md:w-[min(85vw,320px)]">
      <div className="flex items-center justify-between p-5">
        <div className="flex items-center gap-3">
          <div className="mahan-logo" aria-label="Mahan AI"><svg viewBox="0 0 100 82" role="img"><path d="M12 65 31 23Q35 14 40 24L52 47Q55 53 60 45L74 20Q78 12 83 22L94 49" fill="none" stroke="currentColor" strokeWidth="15" strokeLinecap="round" strokeLinejoin="round"/><path d="M33 23 52 47" fill="none" stroke="#888888" strokeOpacity=".35" strokeWidth="3.5" strokeLinecap="round"/></svg></div>
          <div><div className="text-[17px] font-extrabold tracking-tight">Mahan AI</div><div className="muted text-[10px]">{language === "fa" ? "فضای هوش مصنوعی شما" : "Your AI workspace"}</div></div>
        </div>
        <button className="ghost-btn !border-0 !p-2 md:hidden" onClick={() => setSidebarOpen(false)} aria-label="بستن منو"><X size={18}/></button>
      </div>
      <div className="px-4"><button className="primary-btn w-full" onClick={newChat}><Plus size={17}/> گفت‌وگوی جدید <span className="mr-auto rounded-md bg-white/20 px-1.5 py-0.5 text-[10px]">⌘ K</span></button></div>
      <div className="px-4 pt-7 pb-2 text-[11px] font-bold muted">گفت‌وگوهای اخیر</div>
      <div className="min-h-0 flex-1 space-y-1 overflow-y-auto px-3">
        {threads.length === 0 && <div className="muted px-3 py-5 text-xs leading-6">گفت‌وگوهای شما اینجا نمایش داده می‌شوند.</div>}
        {threads.map(thread => <div key={thread.id} className={`group flex items-center gap-2 rounded-xl px-3 py-2.5 text-sm ${activeId === thread.id ? "bg-black/[.06] text-neutral-900 dark:bg-white/[.08] dark:text-white" : "hover:bg-black/[.04] dark:hover:bg-white/[.05]"}`}>
          <button className="flex min-w-0 flex-1 items-center gap-2 text-right" onClick={() => setActiveId(thread.id)}><MessageSquare size={15} className="shrink-0 opacity-70"/><span className="truncate">{thread.title}</span></button>
          <button onClick={() => removeThread(thread.id)} className="hidden rounded p-1 opacity-50 hover:bg-red-100 hover:text-red-600 group-hover:block" aria-label="حذف گفت‌وگو"><Trash2 size={14}/></button>
        </div>)}
      </div>
      <div className="m-3 rounded-2xl border p-3" style={{ borderColor: "var(--line)", background: "var(--surface)" }}>
        <div className="mb-2 flex items-center gap-2 text-sm font-bold"><ShieldCheck size={16}/> {language === "fa" ? "پلن رایگان" : "Free plan"}</div>
        <div className="mb-2 flex items-center justify-between text-xs"><span className="muted">{language === "fa" ? "پیام‌های امروز" : "Today’s messages"}</span><strong>{usedToday} / {dailyLimit}</strong></div>
        <div className="mb-3 h-1.5 overflow-hidden rounded-full" style={{ background: "var(--line)" }}><div className="h-full rounded-full bg-black dark:bg-white" style={{ width: `${Math.min(100, usedToday / dailyLimit * 100)}%` }}/></div>
        <div className="muted mb-3 text-xs leading-5">{language === "fa" ? "مصرف ثبت‌شده روی همین مرورگر" : "Usage tracked in this browser"}</div>
        <button className="ghost-btn w-full !border-violet-200 !text-xs !text-violet-600" onClick={() => window.location.assign("/pricing")}>مشاهده پلن‌ها <span>←</span></button>
      </div>
      <div className="border-t p-3" style={{ borderColor: "var(--line)" }}>
        <div className="px-3 py-2 text-xs muted">چت بدون نیاز به ورود فعال است</div>
        <SignedOut>
          <div className="px-2 py-2"><SignInButton mode="modal"><button className="ghost-btn w-full !justify-center !text-sm">ورود</button></SignInButton></div>
        </SignedOut>
        <SignedIn><AccountMenu compact /></SignedIn>
        <button onClick={() => setShowSettings(true)} className="flex w-full items-center gap-3 rounded-xl p-3 text-sm hover:bg-black/[.04] dark:hover:bg-white/[.05]"><Settings2 size={17}/> تنظیمات برنامه</button>
        <div className="flex items-center justify-between px-3 py-2"><span className="muted text-xs">{language === "fa" ? "ظاهر برنامه" : "Appearance"}</span><button className="ghost-btn !p-2" onClick={() => setDark(!dark)} aria-label="تغییر تم">{dark ? <Sun size={16}/> : <Moon size={16}/>}</button></div>
        <div className="flex items-center justify-between px-3 py-2"><span className="muted text-xs">{language === "fa" ? "زبان رابط" : "Interface language"}</span><button className="ghost-btn !px-3 !py-1.5 text-xs" onClick={() => setLanguage(language === "fa" ? "en" : "fa")}>{language === "fa" ? "English" : "فارسی"}</button></div>
      </div>
    </aside>}
    <section className="flex min-w-0 flex-1 flex-col">
      <header className="mobile-topbar flex h-[68px] shrink-0 items-center justify-between border-b px-4 md:px-7" style={{ borderColor: "var(--line)" }}>
        <div className="mobile-top-left">
          <button className="mobile-icon-button" onClick={newChat} aria-label="گفت‌وگوی جدید"><Plus size={22}/></button>
        </div>
        <div className="mobile-top-center relative"><button onClick={() => setModelMenuOpen(!modelMenuOpen)} aria-expanded={modelMenuOpen}><span>{selectedModel?.label ?? "Mahan AI"}</span><ChevronDown size={15}/></button>
          {modelMenuOpen && <div className="surface absolute left-1/2 top-[calc(100%+8px)] z-50 w-[min(88vw,340px)] -translate-x-1/2 overflow-hidden rounded-2xl border p-2 text-right shadow-xl" dir={language === "fa" ? "rtl" : "ltr"}>
            <div className="muted px-3 py-2 text-xs">{language === "fa" ? "انتخاب مدل هوش مصنوعی" : "Choose an AI model"}</div>
            {models.map(m => <button key={m.id} disabled={!demoMode && !m.configured} onClick={() => { setModelId(m.id); setModelMenuOpen(false); }} className={`flex w-full items-center gap-3 rounded-xl p-3 text-right hover:bg-black/[.05] disabled:cursor-not-allowed disabled:opacity-45 dark:hover:bg-white/[.06] ${m.id === modelId ? "bg-black/[.06] dark:bg-white/[.08]" : ""}`}>
              <span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-xl border"><Bot size={17}/></span>
              <span className="min-w-0 flex-1"><span className="block text-sm font-bold">{m.label}</span><span className="muted block text-xs">{m.providerLabel} · {m.description}</span></span>
              <span className={`h-2 w-2 shrink-0 rounded-full ${m.configured ? "bg-emerald-500" : "bg-neutral-400"}`}/>
            </button>)}
            {!demoMode && !models.some(m => m.configured) && <p className="muted px-3 py-2 text-xs leading-5">{language === "fa" ? "هیچ کلید API شناسایی نشد. نام متغیرها را در Render بررسی کنید." : "No API key detected. Check your Render environment variables."}</p>}
          </div>}
        </div>
        <div className="mobile-top-right"><button className="mobile-icon-button" onClick={() => setSidebarOpen(true)} aria-label="باز کردن منو"><Menu size={23}/></button></div>
        <div className="desktop-header-left flex items-center gap-3">
          {!sidebarOpen && <button className="ghost-btn !p-2" onClick={() => setSidebarOpen(true)} aria-label="باز کردن منو"><Menu size={18}/></button>}
          <div className="relative">
            <button className="ghost-btn !gap-2 !rounded-xl !px-3 !py-2" onClick={() => setModelMenuOpen(!modelMenuOpen)}>
              <span className="flex h-7 w-7 items-center justify-center rounded-lg border"><Bot size={16}/></span>
              <span className="text-right"><span className="block text-xs font-bold">{selectedModel?.label ?? "انتخاب مدل"}</span><span className="muted block text-[10px]">{selectedModel?.providerLabel ?? "مدلی موجود نیست"}</span></span>
              <ChevronDown size={15} className="muted"/>
            </button>
            {modelMenuOpen && <div className="surface absolute right-0 top-[calc(100%+8px)] z-20 w-72 overflow-hidden rounded-2xl p-2 shadow-xl">
              <div className="muted px-3 py-2 text-xs">انتخاب مدل هوش مصنوعی</div>
              {models.map(m => <button key={m.id} disabled={!demoMode && !m.configured} onClick={() => { setModelId(m.id); setModelMenuOpen(false); }} className={`flex w-full items-center gap-3 rounded-xl p-3 text-right hover:bg-black/[.05] disabled:cursor-not-allowed disabled:opacity-45 dark:hover:bg-white/[.06] ${m.id === modelId ? "bg-black/[.06] dark:bg-white/[.08]" : ""}`}>
                <span className="flex h-9 w-9 items-center justify-center rounded-xl border"><Bot size={17}/></span>
                <span className="min-w-0 flex-1"><span className="block text-sm font-bold">{m.label}</span><span className="muted block text-xs">{m.providerLabel} · {m.description}</span></span>
                <span className={`h-2 w-2 rounded-full ${m.configured ? "bg-emerald-500" : "bg-amber-400"}`}/>
              </button>)}
              {models.length === 0 && <div className="muted p-4 text-sm">مدلی پیکربندی نشده است.</div>}
            </div>}
          </div>
        </div>
        <div className="desktop-header-right flex items-center gap-2">
          <SignedOut><SignInButton mode="modal"><button className="ghost-btn !px-3 !py-2 text-xs">ورود</button></SignInButton></SignedOut>
          <SignedIn><AccountMenu /></SignedIn>
          <button className="ghost-btn !px-2 !py-2 text-xs" onClick={() => setLanguage(language === "fa" ? "en" : "fa")} aria-label="Change language">{language === "fa" ? "EN" : "فا"}</button>
          <button className="ghost-btn !border-0 !p-2" onClick={() => setDark(!dark)} aria-label="Toggle theme">{dark ? <Sun size={17}/> : <Moon size={17}/>}</button>
          <span className={`hidden rounded-full px-2.5 py-1 text-[10px] sm:inline-flex ${demoMode ? "bg-amber-500/10 text-amber-600" : "bg-emerald-500/10 text-emerald-600"}`}>{demoMode ? "حالت نمایشی" : "اتصال سرور"}</span>
          <button className="ghost-btn !border-0 !p-2" aria-label="راهنما" onClick={() => setToast("برای استفاده واقعی، تنظیمات محیطی و راهنمای نصب پروژه را بررسی کنید.")}><CircleHelp size={18}/></button>
        </div>
      </header>

      <div className="flex min-h-0 flex-1 flex-col overflow-y-auto">
        {!activeThread || activeThread.messages.length === 0 ? <div className="mx-auto flex w-full max-w-4xl flex-1 flex-col justify-center px-5 pb-8 pt-12">
          <div className="mb-8 text-center">
            <div className="mahan-welcome-logo"><svg viewBox="0 0 100 82" role="img"><path d="M12 65 31 23Q35 14 40 24L52 47Q55 53 60 45L74 20Q78 12 83 22L94 49" fill="none" stroke="currentColor" strokeWidth="15" strokeLinecap="round" strokeLinejoin="round"/><path d="M33 23 52 47" fill="none" stroke="#888888" strokeOpacity=".35" strokeWidth="3.5" strokeLinecap="round"/></svg></div>
            <div className="mb-3 text-sm font-semibold mobile-welcome-eyebrow">یک قدم جلوتر با هوش مصنوعی</div>
            <h1 className="mb-4 text-3xl font-black leading-[1.5] tracking-tight md:text-[42px] mobile-welcome-title">{language === "fa" ? "از کجا شروع کنیم؟" : "Where should we start?"}</h1>
            <p className="muted mx-auto max-w-xl text-sm leading-7 md:text-base">{language === "fa" ? "ایده‌هایت را بررسی کن، بنویس، یاد بگیر و مسائل پیچیده را حل کن؛ همه در یک فضای یکپارچه." : "Explore ideas, write, learn, and solve complex problems in one unified workspace."}</p>
          </div>
          <div className="mx-auto grid w-full max-w-3xl grid-cols-1 gap-3 sm:grid-cols-2 mobile-starter-prompts">
            {starterPrompts.map(p => <button key={p.title} onClick={() => { setInput(p.prompt); textareaRef.current?.focus(); }} className="surface group rounded-2xl p-4 text-right transition hover:-translate-y-0.5 hover:border-violet-300 hover:shadow-lg hover:shadow-violet-500/5">
              <div className="mb-3 flex items-center justify-between"><span className="flex h-9 w-9 items-center justify-center rounded-xl bg-violet-500/10 text-lg text-violet-500">{p.icon}</span><span className="muted text-lg transition group-hover:-translate-x-1">←</span></div>
              <div className="mb-1 text-sm font-bold">{p.title}</div><div className="muted text-xs leading-6">{p.detail}</div>
            </button>)}
          </div>
        </div> : <div className="mx-auto w-full max-w-4xl flex-1 px-4 py-8 md:px-8">
          {activeThread.messages.map((m, i) => <div key={i} className={`mb-8 flex gap-3 ${m.role === "user" ? "flex-row" : "flex-row"}`}>
            <div className={`flex h-9 w-9 shrink-0 items-center justify-center rounded-xl ${m.role === "assistant" ? "bg-violet-600 text-white" : "surface"}`}>{m.role === "assistant" ? <Sparkles size={17}/> : <span className="text-xs font-bold">شما</span>}</div>
            <div className="min-w-0 flex-1 pt-1">
              <div className="mb-2 text-xs font-bold">{m.role === "assistant" ? selectedModel?.label ?? "Mahan AI" : "شما"} {m.demo && <span className="mr-2 rounded bg-amber-500/10 px-2 py-1 font-normal text-amber-600">نمایشی</span>}</div>
              <div className="prose prose-sm max-w-none break-words leading-8 dark:prose-invert prose-pre:overflow-x-auto prose-pre:rounded-xl prose-pre:bg-[#171923] prose-pre:p-4 prose-code:rounded prose-code:bg-violet-500/10 prose-code:px-1 prose-code:py-0.5">
                <ReactMarkdown remarkPlugins={[remarkGfm]}>{m.content}</ReactMarkdown>
              </div>
              {m.role === "assistant" && <button onClick={() => copyText(m.content)} className="ghost-btn mt-3 !rounded-lg !border-0 !px-2 !py-1.5 text-xs muted"><Copy size={13}/> کپی پاسخ</button>}
            </div>
          </div>)}
          {busy && <div className="mb-6 flex items-center gap-3"><div className="flex h-9 w-9 items-center justify-center rounded-xl bg-violet-600 text-white"><Sparkles size={17}/></div><div className="flex items-center gap-2 text-sm muted"><span className="flex gap-1"><i className="h-1.5 w-1.5 animate-bounce rounded-full bg-violet-500"/><i className="h-1.5 w-1.5 animate-bounce rounded-full bg-violet-500 [animation-delay:120ms]"/><i className="h-1.5 w-1.5 animate-bounce rounded-full bg-violet-500 [animation-delay:240ms]"/></span>در حال فکر کردن...</div></div>}
          <div ref={bottomRef}/>
        </div>}
      </div>

      <div className="composer-wrap mx-auto w-full max-w-4xl px-4 pb-3 pt-2 md:px-8">
        <div className="surface rounded-[22px] p-3 shadow-lg shadow-black/[.025] transition focus-within:border-violet-300 focus-within:shadow-violet-500/5">
          <textarea ref={textareaRef} value={input} onChange={e => setInput(e.target.value)} onKeyDown={e => { if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); void sendMessage(); } }} rows={2} placeholder={language === "fa" ? "هر چیزی که در ذهن داری، اینجا بنویس..." : "Message Mahan AI..."} className="max-h-40 min-h-[54px] w-full resize-y bg-transparent px-2 py-2 text-sm leading-7 outline-none placeholder:muted" />
          <div className="flex items-center justify-between border-t pt-3" style={{ borderColor: "var(--line)" }}>
            <div className="flex items-center gap-1">
              <button className="ghost-btn !border-0 !p-2 muted" title="افزودن فایل (به‌زودی)" onClick={() => setToast("آپلود فایل تا زمان پیکربندی Storage فعال نیست.")}><ImagePlus size={18}/></button>
              <button className="ghost-btn !border-0 !p-2 muted" title="راهنمای استفاده" onClick={() => setToast("Enter برای ارسال و Shift+Enter برای خط جدید.")}><FileText size={17}/></button>
              <span className="muted mr-1 hidden text-[10px] sm:inline">Shift + Enter برای خط جدید</span>
            </div>
            <button disabled={!input.trim() || busy || !selectedModel} onClick={() => void sendMessage()} className="primary-btn !rounded-xl !px-3 !py-2.5 disabled:cursor-not-allowed disabled:opacity-40" aria-label="ارسال پیام">{busy ? <span className="text-xs">در حال پردازش</span> : <><span className="text-xs">{language === "fa" ? "ارسال پیام" : "Send message"}</span><Send size={15}/></>}</button>
          </div>
        </div>
        <div className="muted py-3 text-center text-[10px] leading-5">Mahan AI ممکن است اشتباه کند. پاسخ‌های مهم را بررسی کنید. <span className="mx-1">·</span> <button onClick={() => setShowSettings(true)} className="hover:text-violet-500">حریم خصوصی و تنظیمات</button></div>
      </div>
    </section>
    <aside className="model-rail">
      <div className="model-rail-head"><h2>انتخاب مدل</h2><Settings2 size={18}/></div>
      <div className="model-categories"><span className="active">همه</span><span>متن</span><span>تصویری</span><span>کدنویسی</span></div>
      <div className="model-rail-list">
        {models.map((m, i) => <button key={m.id} onClick={() => setModelId(m.id)} className={`model-rail-card ${m.id === modelId ? "selected" : ""}`}>
          <span className={`model-rail-icon provider-${m.provider.toLowerCase().replace(/[^a-z]/g, "")}`}>{m.provider === "openai" ? "◎" : m.provider === "google" ? "G" : m.provider === "anthropic" ? "AI" : m.provider === "deepseek" ? "◈" : m.provider === "xai" ? "𝕏" : m.provider === "mistral" ? "M" : m.provider === "perplexity" ? "✳" : "✦"}</span>
          <span className="model-rail-copy"><span className="model-rail-title">{m.label}<small>{m.configured ? "آماده" : "تنظیم نشده"}</small></span><span className="model-rail-description">{m.providerLabel} · {m.description}</span></span>
        </button>)}
        {models.length === 0 && <div className="model-rail-empty">مدلی پیکربندی نشده است.</div>}
      </div>
      <button className="model-rail-all" onClick={() => setModelMenuOpen(true)}>{language === "fa" ? "مشاهده و انتخاب مدل‌ها" : "Browse all models"}　⌄</button>
    </aside>
    {showSettings && <div className="fixed inset-0 z-40 flex items-center justify-center bg-black/40 p-4" onClick={() => setShowSettings(false)}>
      <div className="surface w-full max-w-lg rounded-3xl p-6 shadow-2xl" onClick={e => e.stopPropagation()}>
        <div className="mb-5 flex items-center justify-between"><h2 className="text-lg font-extrabold">حساب و پلن‌ها</h2><button className="ghost-btn !p-2" onClick={() => setShowSettings(false)}><X size={17}/></button></div>
        <p className="muted mb-5 text-sm leading-7">نسخه فعلی رابط کاربری در حال آماده‌سازی است. پرداخت و مدیریت اشتراک تا زمان پیکربندی امن درگاه و پایگاه داده فعال نیست.</p>
        <div className="grid gap-3 sm:grid-cols-3">{[{name:"رایگان",price:"۰",detail:"سهمیه پایه"},{name:"Plus",price:"تنظیم شود",detail:"سهمیه بیشتر"},{name:"Pro",price:"تنظیم شود",detail:"دسترسی پیشرفته"}].map(p => <div key={p.name} className="rounded-2xl border p-4" style={{ borderColor: "var(--line)" }}><div className="font-bold">{p.name}</div><div className="my-3 text-lg font-extrabold">{p.price}</div><div className="muted text-xs">{p.detail}</div></div>)}</div>
        <button className="primary-btn mt-5 w-full" onClick={() => setShowSettings(false)}>متوجه شدم</button>
      </div>
    </div>}
    {toast && <div role="status" className="fixed bottom-5 left-5 z-50 max-w-[90vw] rounded-xl bg-[#242432] px-4 py-3 text-sm text-white shadow-xl">{toast}</div>}
  </main>;
}

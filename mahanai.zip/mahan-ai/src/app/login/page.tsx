"use client";
import Link from "next/link";
import { SignIn } from "@clerk/nextjs";

export default function LoginPage() {
  const enabled = Boolean(process.env.NEXT_PUBLIC_CLERK_PUBLISHABLE_KEY);
  return <main className="app-shell flex min-h-screen items-center justify-center p-4">
    <section className="surface w-full max-w-md rounded-[28px] border p-6 sm:p-8">
      <Link href="/" className="mb-6 inline-flex text-sm muted">← بازگشت به Mahan AI</Link>
      <h1 className="mb-2 text-2xl font-black">ورود یا ثبت‌نام</h1>
      <p className="muted mb-6 text-sm leading-7">برای چت با هوش مصنوعی نیازی به ورود نیست. ورود اختیاری است.</p>
      {enabled ? <SignIn /> : <div className="rounded-2xl border p-4 text-sm leading-7">
        ورود اختیاری با Clerk آماده است، اما برای فعال‌شدن باید در Render متغیرهای <code>NEXT_PUBLIC_CLERK_PUBLISHABLE_KEY</code> و <code>CLERK_SECRET_KEY</code> را پس از ساخت برنامه در Clerk اضافه کنی.
      </div>}
    </section>
  </main>;
}

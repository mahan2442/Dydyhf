import { getAvailableModels } from "@/lib/models/catalog";

export const dynamic = "force-dynamic";
export async function GET() {
  const models = getAvailableModels();
  return Response.json({ models, demoMode: process.env.DEMO_MODE !== "false" }, {
    headers: { "Cache-Control": "no-store" }
  });
}

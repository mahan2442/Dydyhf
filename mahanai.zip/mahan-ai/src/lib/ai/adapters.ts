import type { ChatMessage, NormalizedResult, ProviderAdapter } from "@/lib/ai/types";
import type { ModelDefinition } from "@/lib/models/catalog";

function getKey(model: ModelDefinition): string {
  const key = process.env[model.envKey];
  if (!key) throw new Error("PROVIDER_NOT_CONFIGURED");
  return key;
}

async function readJson(response: Response) {
  const body = await response.json().catch(() => ({}));
  if (!response.ok) {
    const message = typeof body?.error?.message === "string" ? body.error.message : `Provider request failed (${response.status})`;
    throw new Error(`PROVIDER_ERROR:${response.status}:${message.slice(0, 300)}`);
  }
  return body;
}

const openAICompatible: ProviderAdapter = {
  async generate(model, messages, signal) {
    const response = await fetch(`${model.baseUrl}/chat/completions`, {
      method: "POST",
      headers: { Authorization: `Bearer ${getKey(model)}`, "Content-Type": "application/json" },
      body: JSON.stringify({ model: model.id, messages, stream: false }),
      signal,
      cache: "no-store"
    });
    const data = await readJson(response);
    const text = data.choices?.[0]?.message?.content;
    if (typeof text !== "string" || !text.trim()) throw new Error("EMPTY_PROVIDER_RESPONSE");
    return {
      text,
      usage: { inputTokens: data.usage?.prompt_tokens, outputTokens: data.usage?.completion_tokens, estimated: !data.usage }
    };
  }
};

const anthropic: ProviderAdapter = {
  async generate(model, messages, signal) {
    const system = messages.filter(m => m.role === "system").map(m => m.content).join("\n");
    const conversation = messages.filter(m => m.role !== "system");
    const response = await fetch(`${model.baseUrl}/messages`, {
      method: "POST",
      headers: { "x-api-key": getKey(model), "anthropic-version": "2023-06-01", "content-type": "application/json" },
      body: JSON.stringify({ model: model.id, max_tokens: 2048, system, messages: conversation.map(m => ({ role: m.role, content: m.content })) }),
      signal,
      cache: "no-store"
    });
    const data = await readJson(response);
    const text = (data.content ?? []).filter((x: { type: string }) => x.type === "text").map((x: { text: string }) => x.text).join("\n");
    if (!text.trim()) throw new Error("EMPTY_PROVIDER_RESPONSE");
    return { text, usage: { inputTokens: data.usage?.input_tokens, outputTokens: data.usage?.output_tokens, estimated: !data.usage } };
  }
};

const gemini: ProviderAdapter = {
  async generate(model, messages, signal) {
    const key = getKey(model);
    const contents = messages.filter(m => m.role !== "system").map(m => ({
      role: m.role === "assistant" ? "model" : "user",
      parts: [{ text: m.content }]
    }));
    const systemInstruction = messages.filter(m => m.role === "system").map(m => m.content).join("\n");
    const url = `${model.baseUrl}/models/${encodeURIComponent(model.id)}:generateContent?key=${encodeURIComponent(key)}`;
    const response = await fetch(url, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ contents, ...(systemInstruction ? { systemInstruction: { parts: [{ text: systemInstruction }] } } : {}) }),
      signal,
      cache: "no-store"
    });
    const data = await readJson(response);
    const text = (data.candidates?.[0]?.content?.parts ?? []).map((p: { text?: string }) => p.text ?? "").join("");
    if (!text.trim()) throw new Error("EMPTY_PROVIDER_RESPONSE");
    return { text, usage: { inputTokens: data.usageMetadata?.promptTokenCount, outputTokens: data.usageMetadata?.candidatesTokenCount, estimated: !data.usageMetadata } };
  }
};

export function adapterFor(model: ModelDefinition): ProviderAdapter {
  if (model.apiStyle === "anthropic") return anthropic;
  if (model.apiStyle === "gemini") return gemini;
  return openAICompatible;
}
